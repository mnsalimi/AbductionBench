# Related Work: research decisions and evidence

Research cutoff: September 6, 2026. This is an author-facing companion, not additional main-text prose. The paper-ready section is `Sections/3_related_work.tex`; the operational taxonomy and both comparison tables are in `Sections/Appendix/related_work_coverage.tex` and are included in the manuscript.

## Scope and structure

The section follows three steps: (1) group benchmark formulations by what they ask models to do; (2) distinguish what their metrics establish from adjacent capabilities they do not separately measure; (3) compare increasingly close multi-benchmark efforts. The closing paragraph positions AbductionBench by its intended joint protocol coverage, not a completeness or priority claim.

The structural references were inspected, not used as wording sources:
- [MuSR, Background and Motivation, Section 2 and Table 1](https://arxiv.org/abs/2310.16049): properties of an evaluation setting, then complementary coverage. Only its murder-mystery subset is discussed here; the full benchmark is not uniformly abductive.
- [MIRAGE, Related Work, Section 6](https://arxiv.org/html/2410.09542): distinguish direct hypothesis assessment from downstream predictive evaluation rather than treating them as interchangeable.
- [SWE-bench, Related Work, Section 6](https://arxiv.org/html/2310.06770): move from the evaluation problem to the closest artifacts. These structural inspirations do not need citations in the main argument.

The detailed matrices are in the appendix to preserve the main-section budget. The benchmark matrix has 25 protocol rows, including distinct formulations of the same resource. It is deliberately representative, not a verified matrix for all 48 entries. External comparison tasks are marked and have not been added to the evaluated collection.

## Proposed operational taxonomy

| Group | Targets | What would constitute evidence? |
|---|---|---|
| Hypothesis formation | Generation; coverage of alternatives | Construct a missing explanation; assess distinct valid answers or recovery against an admissible set. Sampling several answers alone is insufficient. |
| Hypothesis assessment | Evidence support, consistency, contextual plausibility, parsimony | Distinguish solver checks, gold-reference matches, human/judge assessment, and proxies. Define minimality relative to a theory or cost, not simply response length. |
| Hypothesis discrimination | Selection, ranking, verification; calibrated uncertainty | Identify appropriate candidate(s), preserve set-valued targets, or compare reported probabilities with correctness. Uncertainty words and alternative enumeration are not calibration. |
| Hypothesis revision and use | Static theory repair; evidence-triggered updating; predictive testing; active acquisition | Score repaired theories, reassess conclusions after new evidence, test inferred hypotheses on new cases, or measure informative queries/experiments. These are related but distinct targets. |

The eight matrix columns compact this taxonomy: G generation; S selection/ranking/verification; Q explanatory adequacy; M multiple explanations; R revision/repair; P held-out hypothesis use; U calibration; A active acquisition. Qualifiers distinguish joint causes from rival explanations, static repair from evidence updates, and prediction-domain coverage from predictive correctness.

These are operational targets, not a validated psychometric factorization. The paper's generation–selection taxonomy remains the principal task axis. Output modality, finite/open candidate space, domain, and static/sequential/interactive delivery are descriptors, not automatic capability scores. Evidence integration and multistep reasoning require depth/evidence manipulations or process-sensitive scoring to support independent conclusions. Cross-domain testing is breadth; transfer requires a specified training/adaptation and held-out evaluation design.

## Primary-source audit ledger

The following locators support the protocol-level coding. A dash in the matrix means “not separately evaluated in this formulation,” not “impossible” or “a defective dataset.”

| Resource | Primary source and decisive scope |
|---|---|
| ART | [ICLR paper, Sections 2–5](https://arxiv.org/pdf/1908.05739): alphaNLI choice and alphaNLG construction are separate tasks; generation includes human plausibility assessment. |
| e-CARE | [ACL paper](https://aclanthology.org/2022.acl-long.33/): restrict abductive selection to cause-directed questions; the generation task explains a supplied cause–effect pair. |
| UNcommonsense | [NAACL paper](https://aclanthology.org/2024.naacl-long.469/): generated explanations for unusual outcomes; plausibility evaluation is not exhaustive alternative coverage. |
| True Detective | [*SEM paper](https://aclanthology.org/2023.starsem-1.28/): mystery-answer selection, not independent generation. |
| MuSR | [ICLR paper, Sections 2 and 4.1](https://arxiv.org/abs/2310.16049): dispersed clues and multistep soft reasoning; restrict the comparison to murder mysteries. |
| AER | [Task paper, Section 3.4](https://arxiv.org/html/2603.21720): multiple supported direct causes; joint causes need not be alternative explanations. |
| ProofWriter | [Findings paper, Sections 3.8 and 5.5, Tables 8–9](https://aclanthology.org/2021.findings-acl.317/): abductive generation of all individually sufficient missing facts, with set evaluation; distinct from entailment prediction. |
| AbductionRules | [Findings paper, Section 3.1.4](https://aclanthology.org/2022.findings-acl.19/): a single missing fact is the target, despite the benchmark name. |
| NeuLR | [Paper](https://arxiv.org/html/2306.09841), [author repository](https://github.com/DeepReasoning/NeuLR): use the abductive missing-premise subset, not a generic relation-classification label for the entire resource. |
| AbductiveKGR | [ACL paper](https://aclanthology.org/2024.acl-long.72/): formula generation and agreement with observed answer sets; RLF-KG names the learning method. |
| ABD | [Paper, benchmark definition and evaluation](https://arxiv.org/html/2602.18843): sparse exception rules and held-out-world validity; static theory repair rather than active evidence acquisition. |
| DeFAb | [Paper, L2 and L3 protocols](https://arxiv.org/html/2606.18557): main L2 experiments select candidates; L3 construction is distinct; derivability, conservativity, and minimality are explicit. Do not merge these with CONJURE. |
| HypoSpace | [Paper, v3](https://arxiv.org/html/2510.15614): validity, uniqueness, and set recovery under underdetermination; no automatic calibration or active-experiment credit. |
| DDXPlus | [Paper, Section 5 and Appendix H](https://arxiv.org/html/2205.09148): native interactive differential diagnosis over a disease vocabulary; generating free-text diagnoses is a separate adaptation. |
| MedCaseReasoning | [Paper, Sections 2–3](https://arxiv.org/html/2505.11733): final diagnosis plus clinician-reasoning recall; the latter is not a full proof of explanatory correctness. |
| HypoBench | [Paper](https://arxiv.org/html/2504.11524), [implementation](https://github.com/ChicagoHAI/hypothesis-generation): natural-language hypotheses evaluated via predictive use and planted-hypothesis recovery; recovered components are not necessarily rival explanations. |
| BoxingGym | [Paper, Section 3.2](https://arxiv.org/html/2501.01540): experimental informativeness and predictive use of explanations; revision is available but not an independent correctness score. |
| Cloud-OpsBench | [Paper, v2](https://arxiv.org/html/2603.00468): root-cause outcomes and investigation/evidence milestones are distinct; the August revision supersedes the earlier task counts. |
| GEAR | [Paper, Sections 3–4, 5.2–5.3 and Appendix E](https://arxiv.org/html/2509.24096): executable hypothesis sets; main generalizability measures defined prediction coverage. Hidden-case correctness is a separate analysis. |
| Elenchos | [Paper](https://arxiv.org/html/2607.12733): interactive diagnosis within a specified kernel-mutation ontology; structured textual output is not unrestricted hypothesis construction. |
| Black Swan | [Paper](https://arxiv.org/html/2412.05725): separate generative, multiple-choice, and yes/no variants; explicit evidence-update comparisons. Not every Reporter/Detective variant measures the same reasoning type. |
| MolQuest | [Paper, Sections 3.3–3.4](https://arxiv.org/html/2603.25253): molecular hypothesis generation, tool-mediated spectral evidence acquisition, and RMSCE calibration; do not substitute Brier score for its reported metric. |

## Closest comparisons and version checks

The appendix comparison includes GEAR, Wiring the 'Why', HypoBench, HypoSpace, CEDAR-GRPO, Elenchos, IBE evaluation, broader logical evaluation, and BoxingGym. These are not all equivalent direct predecessors: some are multi-dataset runners, others generated task families, multi-environment systems, or training studies.

- **GEAR:** latest arXiv version inspected is v1, September 28, 2025. Its [released repository](https://github.com/KaiyuHe998/GEAR-Abduction_evaluation) contains generation and evaluation components. Distinguish its common executable representation from native-interface preservation, not “framework versus no framework.” Evaluator-side scoring is not a model selection task.
- **Wiring the 'Why':** latest arXiv version inspected is [v2, April 23, 2026](https://arxiv.org/abs/2604.08016v2). Section 4.1 and Appendix 8.1 describe nine unique datasets and twelve formulations (five selection, seven generation, three shared resources). It uses heterogeneous metrics and controlled direct prompts. Its empirical suite supports the survey's questions; no claim is made that reusable code does not exist.
- **CEDAR-GRPO:** [August 14, 2026 preprint](https://arxiv.org/html/2608.14791) and [public implementation](https://github.com/cedar-grpo/cedar-grpo). This is significant overlap: the repository includes `GRPO/Evaluation/evaluate_all.py` and task-specific evaluation. The eleven held-out tasks include non-abductive controls; trace uncertainty markers are not calibration. The defensible difference is objective and joint protocol scope, not absence of prior reusable execution.
- **HypoBench:** inspected v2, February 10, 2026. It already provides multi-dataset hypothesis evaluation and public code. Its twelve tasks/194 datasets use different counting units from this paper's 48 entries.
- **HypoSpace:** inspected v3, May 29, 2026. It is a multi-domain diagnostic evaluation, not merely an isolated dataset. Cite the verified preprint rather than an unverified conference record.
- **Elenchos:** July 14, 2026 preprint. A dedicated interactive evaluation framework, but not a collection of existing heterogeneous datasets. Extensibility does not establish evaluation across many domains.
- **Dalal et al.:** [ACL 2024, pp. 217–235](https://aclanthology.org/2024.acl-long.14/), with [IBE-eval code](https://github.com/dhairyadalal/IBE-eval). A two-dataset explanation-quality predecessor.
- **Xu et al.:** the [author-maintained repository](https://github.com/DeepReasoning/NeuLR) confirms the final publication as IEEE TKDE 37(4), 1620–1634 (2025), not merely a 2023 preprint. The BibTeX key is retained for compatibility.

Searches explicitly covered multi-benchmark abductive evaluation/frameworks through 2026, including interactive evaluation and hypothesis generation. Additional candidates such as [InteractiveBench](https://arxiv.org/html/2603.04737) were screened but not treated as dedicated abductive multi-dataset predecessors. This targeted search is not proof of exhaustive coverage or absence of an earlier implementation.

## Added, merged, and omitted categories

- **Added explicit evidence updating and calibration:** Black Swan and MolQuest supply observable protocols for targets that cannot be inferred from “interactive” or “multiple hypotheses.” They are external related-work examples, not new evaluated datasets.
- **Added multi-dataset scientific hypothesis evaluation and process-aware training evaluation:** HypoBench and CEDAR-GRPO materially constrain novelty; omitting them would overstate the gap.
- **Merged domains into capability families:** diagnosis, formal reasoning, and scientific discovery illustrate distinct measurement choices rather than separate dataset catalogues.
- **Retained a short coverage synthesis:** it explains why metrics and target sets cannot be collapsed into one competence score, without repeating each dataset description.
- **Omitted general evaluation-framework history:** HELM/harness/OpenCompass would consume space without improving the direct comparison.
- **Omitted a full philosophy survey and standalone prompting survey:** the brief definition grounds the scope; the requested argument is about evaluation coverage and direct predecessors. Existing prompting/format precedents are acknowledged where relevant.
- **Omitted a universal all-dataset checkmark matrix:** the current paper mixes datasets, suites, methods, and task variants; unverified binary labels would produce false precision. The representative matrix states its unit and its limits.

## Unsafe novelty claims and safer alternatives

| Unsafe or ambiguous claim | Safer alternative / evidence needed |
|---|---|
| “The first unified/reusable abductive evaluation framework.” | “Extends prior evaluation frameworks toward joint evaluation of heterogeneous interfaces and protocols.” GEAR, CEDAR-GRPO, HypoBench, and interactive frameworks already provide relevant infrastructure. |
| “The first generation–selection taxonomy or multi-dataset comparison.” | Explicitly credit Wiring; distinguish separate tasks from pipelines and specify experimental coverage. |
| “The first to preserve different metrics.” | “Preserves benchmark-specific metrics across the included protocols.” Wiring already combines different metric families. |
| “The first to evaluate generation, choice, and binary verification.” | “Systematically compares these formulations on specified shared instances.” Black Swan already has generative/MCQ/yes-no variants. |
| “Prior work does not evaluate interactive abduction.” | “Compares static, sequential, and interactive protocols while preserving their information budgets.” Cite Elenchos, BoxingGym, and MolQuest. |
| “GEAR tests held-out accuracy as generalizability.” | Distinguish the main defined-prediction coverage metric from separate hidden-case correctness analyses. |
| “Forty-eight independent abductive datasets; largest/complete coverage.” | “A collection of 48 benchmark-table entries,” pending normalization of suites, methods, and variants. No verified largest/complete claim. |
| “Multiple outputs establish calibrated uncertainty.” | Report admissible-set coverage and probability calibration separately. |
| “Interactive tasks test successful hypothesis revision.” | Specify whether revision correctness is scored or merely afforded by the environment. |
| “Cross-domain evaluation demonstrates transfer.” | “Characterizes performance across domains,” unless there is an explicit adaptation/held-out transfer design. |
| “All causal, clinical, or scientific tasks are abductive.” | Identify the observation, unknown explanatory hypothesis, and explanatory success criterion for the actual formulation. |
| “Scores demonstrate general abductive competence.” | Describe measured dimensions and unevaluated dimensions; do not equate heterogeneous metrics. |
| “All adapters/native protocols are implemented and reproducible.” | The workspace contains manuscript files, not an inspectable evaluation implementation. Keep the contribution as a design objective until adapters, splits, configurations, and execution tests are documented. |

## Existing appendix issues requiring reconciliation

These findings are recorded rather than silently changing the dataset collection:
1. The existing ProofWriter row says it only predicts entailment. Its paper explicitly includes an abductive missing-fact task; name the split used.
2. The existing NeuLR row labels the released task as relation selection. The abductive subset instead targets a missing premise; verify the intended adapter.
3. RLF-KG is the method in the AbductiveKGR work. Counting that method as an independent dataset needs correction or explanation.
4. The existing DeFAb row collapses generation and candidate selection. Report the level/protocol actually run.
5. Existing entries such as GEAR are themselves frameworks incorporating multiple tasks. Dataset counts and overlap require a declared counting rule.
6. “Direct support,” “external task-level support,” and “no direct claim found” are evidence-status labels, not independent demonstrations that the evaluated protocol is abductive.

## Bibliography deliverable

Canonical records are in `iclr2027_conference.bib`. Existing citation keys were preserved while correcting GEAR's title/authors, ART's ICLR 2020 publication, e-CARE and AbductionRules' ACL records, True Detective's *SEM 2023 publication, Xu et al.'s TKDE publication, Dalal et al.'s pages, and CEDAR-GRPO's title/authors. Unverified venue assignments for HypoSpace and DeFAb were replaced with the inspected arXiv records. Other existing bibliography entries were not globally audited.

MolQuest is the newly added key; the other introduced in-text references already existed in the project bibliography:

```bibtex
@misc{han2026molquest,
  title={{MolQuest}: A Benchmark for Agentic Evaluation of Abductive Reasoning in Chemical Structure Elucidation},
  author={Han, Taolin and Wu, Shuang and Wang, Jinghang and Zhou, Yuhao and Lv, Renquan and Zhao, Bing and Hu, Wei},
  year={2026},
  eprint={2603.25253},
  archivePrefix={arXiv},
  primaryClass={cs.CL},
  url={https://arxiv.org/abs/2603.25253}
}
```

## Validation

All 26 distinct citation keys in the main section and all 27 in the supporting appendix resolve to bibliography entries. Successive pdfLaTeX passes produced a PDF with no unresolved citations/references or overfull-box warnings; the two new matrices were visually inspected. The main section occupies approximately 1.5 pages of text in the current single-column template, spread across pages 1–2 after the existing title/abstract.

A clean `latexmk` build remains blocked by a pre-existing malformed, percent-commented DiscoveryBench record in `iclr2027_conference.bib` (the line beginning `% @inproceedings{majumder2025discoverybench,`). BibTeX still parses the entry and reports a missing field name. This unrelated disabled record was not changed. Layout validation used the bibliography output that BibTeX produced while skipping that entry; it does not constitute a successful clean full build.